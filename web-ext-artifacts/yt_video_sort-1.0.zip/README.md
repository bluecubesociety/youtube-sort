# Youtube Sort

A Firefox extension that sorts (non-discarded, non-pinned) YouTube videos based on video length.